function setup() {
  createCanvas(400, 400);
  setVolume(0.9);
  duration(30);
}

function draw() {
  background(220);
  stop([30]);
}