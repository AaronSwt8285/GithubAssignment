function setup() {
  createCanvas(800, 800);
 
  
  
  
  
}





function draw() {
  var x = 250;
  var y = 675;
  var w = 200;
  var h = 50;
  
  var a = 600;
  var b = 675;
  var c = 100;
  var d = 100;
  background(205,153,11);
  if(mouseIsPressed == true){
    
    fill(0,200,255);
  }
  else{
    fill(255)
  }
  rect(150,200,400,400);
  
  
  fill(0,0,0);
  ellipse(100, 700, 50, 50);
  rect(250, 675, 200, 50);
  fill(255, 0, 0 );
  ellipse(100, 700, 20, 20);
  fill(0,255,0);
  
  //var d = dist(mouseX, mouseY, a, b);
  
  if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h) && (mouseIsPressed)){
    fill(255,0,0)
  }
  else{
    fill(0)
  }
  rect(x,y,w,h)
  rect(a,b,c,d)
  if ((mouseX > a) && (mouseX < a+c) && (mouseY > b) && (mouseY < b+d) && (keyIsPressed) && (key =='h')){
     line(400, 390, 360, 390)
    line(400, 360, 400, 420)
    line(360, 360, 360, 420)
  }
  
    
   
    
    
    

  
  
  
  
  
  
  
  
}