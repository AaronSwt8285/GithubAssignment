var radius = 40;
var x = -radius;
var speed = 0.5;
let g = 1;
let num = 14;


function setup() {
  frameRate(120);
  createCanvas(400, 400);
   background(200);
  ellipseMode(RADIUS);
  e = -3;
  f = abs(e);

  
  
                 }
function draw() {
  background(200);
  colorMode(RGB, 255, 255, 255, 1);
  a = 100;
  b = 150;
  c = 200;
  strokeWeight(1);
  line(a,b,c, 250);
  if(x > 450){
    x=0
  }
  else{
    x += speed; 
  }
    arc(x, 60, radius, radius, 0.52, 5.76);
 
  line(40, 0, height, 70);
  if(mouseIsPressed == true){
    stroke(102);
  }
  
  y = 45;
  fill(0);
  for (let i = 0; i < num - 1; i++) {
    rect(120, y, 40, 1);
    y += 50;
  }
   if(mouseIsPressed == true){
    stroke(10);
  }
}